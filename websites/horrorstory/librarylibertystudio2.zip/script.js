new fullpage('#fullpage', {
    autoScrolling: true,
    scrollHorizontally: true
}) 

fullpage();